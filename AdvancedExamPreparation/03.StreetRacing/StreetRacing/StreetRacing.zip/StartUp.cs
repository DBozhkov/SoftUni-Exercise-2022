﻿using System;

namespace StreetRacing
{
    public class StartUp
    {
        static void Main(string[] args)
        {
        }
    }
}
