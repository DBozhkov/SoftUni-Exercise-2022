﻿namespace _03.Telephony
{
    public interface IBrowsable
    {
        void Browse();
    }
}
